package th.ac.kmutnb.my_project_iot_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {
    private static final String PREF_NAME = "MyPref";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        SharedPreferences pref = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        String Username = pref.getString("Username", "no record");
//        Intent itn = getIntent();
//        String Username = itn.getStringExtra("Username");
        TextView tv1 = findViewById(R.id.textView);
        tv1.setText(Username);
//        Log.i("MyApp", Username);
    }

    public void LogoutButton_Profile(View v){
        SharedPreferences pref = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("Userid", "-1");
        editor.putString("Username", "-1");
        editor.putBoolean("SessionKey",false);
        editor.apply();
        Intent itn2 = new Intent(this,LoginActivity.class);
        startActivity(itn2);
    }
}